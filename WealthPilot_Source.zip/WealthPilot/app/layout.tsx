import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'WealthPilot | Credit intelligence',description:'An evidence-first workspace for SME underwriting and credit research.'};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>}
