import { getCase,guard,json } from '@/lib/api-store';
export async function GET(_:Request,ctx:{params:Promise<{id:string}>}){return guard(async()=>json({case:await getCase((await ctx.params).id)}));}

import { z } from 'zod';
import { ApiError,body,createSchema,updateCase } from '@/lib/api-store';
import { isFinal,metricKeys } from '@/lib/underwriting';
const patchSchema=createSchema.partial().extend({version:z.number().int().positive()}).strict();
export async function PATCH(req:Request,ctx:{params:Promise<{id:string}>}){return guard(async()=>{const input=patchSchema.parse(await body(req)),c=await getCase((await ctx.params).id);if(isFinal(c))throw new ApiError(409,'Finalized applications cannot be edited. Create a new application for reassessment.');if(c.version!==input.version)throw new ApiError(409,'Application version changed. Refresh before editing.');for(const k of ['company','industry','amount','purpose','years'] as const){if(input[k]!==undefined)Object.assign(c,{[k]:input[k]});}for(const k of metricKeys){if(input[k]!==undefined)c.financials[k]=input[k]!;}
 // Re-evaluate conflicts against every source after application corrections.
 for(const d of c.documents){const parsed=d.metrics||parseFinancialText(d.text);d.conflicts=[...(d.intrinsicConflicts||d.conflicts.filter(s=>s.includes('within'))),...metricKeys.flatMap(k=>parsed[k]!==undefined&&c.financials[k]!==null&&Math.abs(parsed[k]!-c.financials[k]!)>.000001?[`${k}: application ${c.financials[k]}, document ${parsed[k]}`]:[])];d.status=d.conflicts.length?'Conflict':'Parsed';}
 c.analysis=null;c.status='Draft';return json({case:await updateCase(c,input.version,'Application updated','Financial inputs corrected; prior analysis invalidated.','Analyst')});});}
import { parseFinancialText } from '@/lib/underwriting';
