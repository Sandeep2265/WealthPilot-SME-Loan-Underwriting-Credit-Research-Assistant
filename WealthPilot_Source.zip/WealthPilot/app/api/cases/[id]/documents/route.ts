import { assertSameOrigin } from '@/lib/api-store';
import { env } from 'cloudflare:workers';
import { ApiError,getCase,guard,json,updateCase,readBounded } from '@/lib/api-store';
import { isFinal,metricKeys,parseFinancialText } from '@/lib/underwriting';
export async function POST(req:Request,ctx:{params:Promise<{id:string}>}){return guard(async()=>{
 assertSameOrigin(req);const c=await getCase((await ctx.params).id);if(isFinal(c))throw new ApiError(409,'Finalized applications cannot accept new documents. Create a new application for reassessment.');
 if(Number(req.headers.get('content-length')||0)>2_200_000)throw new ApiError(413,'Documents must be no larger than 2 MB.');
 const payload=await readBounded(req,2_200_000);
 let form:FormData;try{form=await new Response(payload,{headers:{'Content-Type':req.headers.get('content-type')||''}}).formData();}catch{throw new ApiError(400,'Choose a valid file to upload.');}
 const file=form.get('file');if(!(file instanceof File))throw new ApiError(400,'Choose a TXT or CSV financial document.');
 if(!/\.(csv|txt)$/i.test(file.name))throw new ApiError(415,'Hosted uploads support TXT and CSV. PDF/OCR requires the portable Python backend.');
 if(file.size===0)throw new ApiError(400,'The document is empty.');if(file.size>2_000_000)throw new ApiError(413,'Documents must be no larger than 2 MB.');if(c.documents.length>=20)throw new ApiError(422,'Maximum 20 source documents per application.');
 const bytes=await file.arrayBuffer();let text:string;try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{throw new ApiError(415,'Use a UTF-8 encoded TXT or CSV document.');}if(text.includes('\0')||text.startsWith('%PDF'))throw new ApiError(415,'This file is not a supported text document.');if(!text.trim())throw new ApiError(400,'The document contains no text.');
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(n=>n.toString(16).padStart(2,'0')).join('');
 if(c.documents.some(d=>d.hash===hash||d.text===text))throw new ApiError(409,'This source document has already been uploaded.');
 const parsed=parseFinancialText(text);if(Object.keys(parsed).length===0)throw new ApiError(422,'No financial metrics found. Use one metric,value per line (for example revenue,420), with amounts in INR lakh.');
 const conflicts:string[]=[];
 const seen:Record<string,number>={};for(const line of text.split(/\r?\n/)){const row=parseFinancialText(line);for(const key of metricKeys){const v=row[key];if(v===undefined||v===null)continue;if(seen[key]!==undefined&&seen[key]!==v)conflicts.push(`${key} has different values within ${file.name}`);seen[key]=v;}}
 const intrinsicConflicts=[...new Set(conflicts)].slice(0,30);
 for(const k of metricKeys){const v=parsed[k];if(v===undefined||v===null)continue;if((k!=='ebitda'&&k!=='equity'&&v<0)||Math.abs(v)>1e12)throw new ApiError(422,`Invalid ${k} in source document.`);if(c.financials[k]!==null&&Math.abs(c.financials[k]!-v)>.000001)conflicts.push(`${k}: application ${c.financials[k]}, document ${v}`);else if(c.financials[k]===null)c.financials[k]=v;}
 if(!env.BUCKET)throw new ApiError(503,'Document storage is unavailable. Please retry later.');
 const id=crypto.randomUUID(),key=`cases/${c.id}/${id}`,name=file.name.replace(/[\u0000-\u001f/\\]/g,'_').slice(0,180),expected=c.version;
 await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:file.name.toLowerCase().endsWith('.csv')?'text/csv':'text/plain'}});
 try {c.documents.push({id,name,size:file.size,uploadedAt:new Date().toISOString(),status:conflicts.length?'Conflict':'Parsed',text:text.slice(0,12000),conflicts:[...new Set(conflicts)].slice(0,30),key,hash,metrics:parsed,intrinsicConflicts});c.analysis=null;c.status='Draft';return json({case:await updateCase(c,expected,'Document uploaded',`${name}; ${Object.keys(parsed).length} metrics recognized; ${conflicts.length} conflicts. Existing analysis invalidated.`)},201);}catch(e){await env.BUCKET.delete(key);throw e;}
 });}
