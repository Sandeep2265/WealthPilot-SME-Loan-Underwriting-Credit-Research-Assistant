import { assertSameOrigin } from '@/lib/api-store';
import { ApiError,getCase,guard,json,updateCase } from '@/lib/api-store';
import { analyzeCase,isFinal } from '@/lib/underwriting';
export async function POST(req:Request,ctx:{params:Promise<{id:string}>}){return guard(async()=>{assertSameOrigin(req);const c=await getCase((await ctx.params).id);if(isFinal(c))throw new ApiError(409,'This application has a recorded final decision and cannot be modified. Create a new application for reassessment.');const v=c.version;c.analysis=analyzeCase(c);c.status='Needs review';return json({case:await updateCase(c,v,'Analysis completed',`${c.analysis.recommendation}; ${c.analysis.blockers.length} unresolved checks. Deterministic pipeline.`)});});}
