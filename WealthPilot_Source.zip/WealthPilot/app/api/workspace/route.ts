import { database,guard,json } from '@/lib/api-store';
import { policies } from '@/lib/underwriting';
export async function GET(){return guard(async()=>{const db=database();const [cases,audit]=await Promise.all([db.prepare('SELECT data FROM credit_cases ORDER BY updated_at DESC LIMIT 500').all<{data:string}>(),db.prepare('SELECT id,case_id as caseId,action,detail,actor,created_at as createdAt FROM credit_audit ORDER BY created_at DESC LIMIT 500').all()]);return json({cases:cases.results.map(r=>JSON.parse(r.data)),policies,audit:audit.results,mode:'Deterministic • no LLM connected'});});}
