import { z } from 'zod';
import { body,getCase,guard,json } from '@/lib/api-store';
import { policies } from '@/lib/underwriting';
const schema=z.object({question:z.string().trim().min(3).max(2000),caseId:z.string().max(100).optional()}).strict();
export async function POST(req:Request){return guard(async()=>{const input=schema.parse(await body(req)),c=input.caseId?await getCase(input.caseId):null;
 const expanded=input.question.toLowerCase().replace(/\bdscr\b/g,'debt service coverage').replace(/\bdocuments?\b/g,'evidence document').replace(/\bhuman approval\b/g,'human reviewer approval'); const words=expanded.match(/[a-z]{3,}/g)||[];const matches=policies.map(p=>({...p,score:words.filter(w=>`${p.title} ${p.text} ${p.category}`.toLowerCase().includes(w)).length})).filter(p=>p.score>0).sort((a,b)=>b.score-a.score).slice(0,3);
 const citations=matches.map(({score,...p})=>p);const answer=matches.length?`Relevant internal policy evidence:\n\n${matches.map(p=>`[${p.id}] ${p.title}: ${p.text}`).join('\n\n')}${c?.analysis?`\n\nApplication context (${c.company}): ${c.analysis.summary}`:''}`:'No relevant passage was found in the six configured internal policies. Rephrase around debt service, liquidity, leverage, eligibility, evidence, or governance. No external research or lending facts have been inferred.';
 return json({answer,citations,mode:'Deterministic keyword retrieval • no LLM connected',disclaimer:'These are coursework policies, not legal or regulatory advice.'});});}
