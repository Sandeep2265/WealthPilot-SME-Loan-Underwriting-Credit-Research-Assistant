import { sqliteTable,text,integer } from 'drizzle-orm/sqlite-core';
export const cases=sqliteTable('credit_cases',{id:text('id').primaryKey(),data:text('data').notNull(),version:integer('version').notNull().default(1),updatedAt:text('updated_at').notNull()});
export const audit=sqliteTable('credit_audit',{id:text('id').primaryKey(),caseId:text('case_id'),action:text('action').notNull(),detail:text('detail').notNull(),actor:text('actor').notNull(),createdAt:text('created_at').notNull()});
