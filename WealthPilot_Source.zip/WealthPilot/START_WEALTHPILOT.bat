@echo off
setlocal
cd /d "%~dp0backend"
if not exist ".venv\Scripts\python.exe" (
  py -m venv .venv
  if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -c "import fastapi, uvicorn, langgraph, multipart, pypdf" >nul 2>&1
if errorlevel 1 (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" start_local.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo WealthPilot could not start. Copy the error above for troubleshooting.
pause
exit /b 1
