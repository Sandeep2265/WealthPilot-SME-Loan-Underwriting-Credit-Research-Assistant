from __future__ import annotations
import hashlib, json, os, secrets, sqlite3, time, uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Literal
from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field, field_validator
from engine import FIELDS, POLICIES, MAX_BYTES, analyze, finite_value, parse_document, research

DB_PATH=os.getenv('WEALTHPILOT_DB',str(Path(__file__).parent/'data'/'wealthpilot.sqlite3'))
app=FastAPI(title='WealthPilot API',version='1.0.0',description='Coursework credit decision support. Demonstration policy; human approval required.')
origins=[x.strip() for x in os.getenv('CORS_ORIGINS','http://localhost:3000,http://127.0.0.1:3000').split(',') if x.strip()]
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_methods=['GET','POST','PATCH','DELETE'],allow_headers=['Content-Type','Authorization'])

def now(): return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
@contextmanager
def db():
    Path(DB_PATH).parent.mkdir(parents=True,exist_ok=True)
    connection=sqlite3.connect(DB_PATH,timeout=15,isolation_level=None); connection.row_factory=sqlite3.Row
    connection.execute('PRAGMA foreign_keys = ON'); connection.execute('PRAGMA journal_mode=WAL')
    try: yield connection
    finally: connection.close()

def initialize():
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY, data TEXT NOT NULL, analysis TEXT, status TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES cases(id), data TEXT NOT NULL, sha256 TEXT NOT NULL, UNIQUE(case_id,sha256))')
        c.execute('CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, case_id TEXT NOT NULL REFERENCES cases(id), event TEXT NOT NULL, data TEXT NOT NULL, created_at TEXT NOT NULL)')
initialize()

async def authorize(request:Request):
    origin=request.headers.get('origin')
    if request.method not in {'GET','HEAD','OPTIONS'} and origin and origin!=str(request.base_url).rstrip('/'):
        raise HTTPException(403,'Cross-origin changes are not allowed. Open the dashboard on this server address.')
    token=os.getenv('WEALTHPILOT_API_TOKEN')
    if token:
        supplied=request.headers.get('authorization','')
        if not secrets.compare_digest(supplied,'Bearer '+token): raise HTTPException(401,'A valid API token is required.')
    elif request.client and request.client.host not in {'127.0.0.1','::1','testclient'}:
        raise HTTPException(403,'Remote access requires WEALTHPILOT_API_TOKEN. Bind local development to 127.0.0.1.')

def row_case(c,id):
    r=c.execute('SELECT * FROM cases WHERE id=?',(id,)).fetchone()
    if not r: raise HTTPException(404,'Application not found.')
    return r

def event(c,id,kind,data): c.execute('INSERT INTO audit(case_id,event,data,created_at) VALUES(?,?,?,?)',(id,kind,json.dumps(data),now()))
def render_case(c,r,full=True):
    out=dict(json.loads(r['data']),id=r['id'],status=r['status'],revision=r['revision'],created_at=r['created_at'],updated_at=r['updated_at'],analysis=json.loads(r['analysis']) if r['analysis'] else None)
    if full:
        out['documents']=[{k:v for k,v in json.loads(d['data']).items() if k!='text'}|{'id':d['id']} for d in c.execute('SELECT * FROM documents WHERE case_id=?',(r['id'],))]
        out['audit']=[dict(x)|{'data':json.loads(x['data'])} for x in c.execute('SELECT * FROM audit WHERE case_id=? ORDER BY id',(r['id'],))]
    return out

class CaseInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    company:str=Field(min_length=2,max_length=120)
    sector:str=Field(min_length=2,max_length=80)
    loan_amount:float=Field(gt=0,le=1e12,allow_inf_nan=False)
    currency:Literal['INR','USD']='INR'
    years:float | None=Field(default=None,ge=0,le=200,allow_inf_nan=False)
    purpose:str=Field(min_length=5,max_length=1000)
    financials:dict[str,float | None]=Field(default_factory=dict)
    @field_validator('company','sector','purpose')
    @classmethod
    def clean(cls,v):
        if not v.strip(): raise ValueError('Must not be blank.')
        return v.strip()
    @field_validator('financials')
    @classmethod
    def valid_financials(cls,v):
        if set(v)-FIELDS: raise ValueError('Unknown financial field.')
        if any(x is not None and finite_value(x) is None for x in v.values()): raise ValueError('Financial values must be finite and within 1e15.')
        return v
class Decision(BaseModel):
    model_config=ConfigDict(extra='forbid')
    decision:Literal['Approved','Declined','Needs information']
    reviewer:str=Field(min_length=2,max_length=100)
    note:str=Field(min_length=10,max_length=2000)
    revision:int=Field(ge=1)
    @field_validator('reviewer','note')
    @classmethod
    def clean(cls,v):
        if not v.strip(): raise ValueError('Must not be blank.')
        return v.strip()
class Question(BaseModel):
    question:str=Field(min_length=1,max_length=2000)

@app.get('/health')
def health(): return {'status':'ok','mode':'deterministic; optional grounded LLM','policy_version':'coursework-demo-v1'}
@app.get('/policies',dependencies=[Depends(authorize)])
def policies(): return {'version':'coursework-demo-v1','retrieval':'local hashed-vector cosine search; not semantic neural embeddings','policies':POLICIES}
@app.get('/cases',dependencies=[Depends(authorize)])
def cases():
    with db() as c: return [render_case(c,r,False) for r in c.execute('SELECT * FROM cases ORDER BY created_at DESC LIMIT 500')]
@app.post('/cases',status_code=201,dependencies=[Depends(authorize)])
def create_case(payload:CaseInput):
    id=str(uuid.uuid4())
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            c.execute('INSERT INTO cases(id,data,status,created_at,updated_at) VALUES(?,?,?,?,?)',(id,payload.model_dump_json(),'Draft',now(),now())); event(c,id,'created',{'company':payload.company}); c.execute('COMMIT')
        except Exception: c.execute('ROLLBACK'); raise
        return render_case(c,row_case(c,id))
@app.get('/cases/{id}',dependencies=[Depends(authorize)])
def get_case(id:str):
    with db() as c: return render_case(c,row_case(c,id))
@app.patch('/cases/{id}',dependencies=[Depends(authorize)])
def update_case(id:str,payload:CaseInput,revision:int):
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            r=row_case(c,id)
            if r['status'] in {'Approved','Declined'}: raise HTTPException(409,'Final decisions are locked. Create a new application for reassessment.')
            if r['revision']!=revision: raise HTTPException(409,'Application changed. Reload the latest revision.')
            c.execute("UPDATE cases SET data=?,analysis=NULL,status='Draft',revision=revision+1,updated_at=? WHERE id=?",(payload.model_dump_json(),now(),id))
            event(c,id,'application_updated',{'previous_revision':revision}); c.execute('COMMIT')
        except Exception: c.execute('ROLLBACK'); raise
        return render_case(c,row_case(c,id))
@app.delete('/cases/{id}/documents/{document_id}',dependencies=[Depends(authorize)])
def remove_document(id:str,document_id:str,revision:int):
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            r=row_case(c,id)
            if r['status'] in {'Approved','Declined'}: raise HTTPException(409,'Final decisions are locked. Create a new application for reassessment.')
            if r['revision']!=revision: raise HTTPException(409,'Application changed. Reload the latest revision.')
            document=c.execute('SELECT * FROM documents WHERE id=? AND case_id=?',(document_id,id)).fetchone()
            if not document: raise HTTPException(404,'Document not found.')
            c.execute('DELETE FROM documents WHERE id=? AND case_id=?',(document_id,id))
            c.execute("UPDATE cases SET analysis=NULL,status='Draft',revision=revision+1,updated_at=? WHERE id=?",(now(),id))
            event(c,id,'document_removed',{'id':document_id,'name':json.loads(document['data'])['name']}); c.execute('COMMIT')
        except Exception: c.execute('ROLLBACK'); raise
        return render_case(c,row_case(c,id))
@app.post('/cases/{id}/documents',status_code=201,dependencies=[Depends(authorize)])
async def upload(id:str,file:UploadFile=File(...)):
    content=await file.read(MAX_BYTES+1)
    try: document=parse_document(file.filename or 'document',content)
    except ValueError as e: raise HTTPException(422,str(e))
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            existing=row_case(c,id)
            if existing['status'] in {'Approved','Declined'}: raise HTTPException(409,'Final decisions are locked. Create a new application for reassessment.')
            if c.execute('SELECT COUNT(*) FROM documents WHERE case_id=?',(id,)).fetchone()[0]>=20: raise HTTPException(422,'Maximum 20 documents per application.')
            if c.execute('SELECT 1 FROM documents WHERE case_id=? AND sha256=?',(id,document['sha256'])).fetchone(): raise HTTPException(409,'This exact document is already attached.')
            doc_id=str(uuid.uuid4()); c.execute('INSERT INTO documents VALUES(?,?,?,?)',(doc_id,id,json.dumps(document),document['sha256']))
            data=json.loads(existing['data'])
            for field, values in document.get('facts',{}).items():
                if data.setdefault('financials',{}).get(field) is None and len(values)==1 and finite_value(values[0]) is not None:
                    data['financials'][field]=values[0]
            c.execute("UPDATE cases SET data=?,analysis=NULL,status='Draft',revision=revision+1,updated_at=? WHERE id=?",(json.dumps(data),now(),id)); event(c,id,'document_attached',{'name':document['name'],'sha256':document['sha256']}); c.execute('COMMIT')
        except Exception: c.execute('ROLLBACK'); raise
    return {k:v for k,v in document.items() if k!='text'}|{'id':doc_id}
@app.post('/cases/{id}/analyze',dependencies=[Depends(authorize)])
def run_analysis(id:str):
    with db() as c:
        r=row_case(c,id)
        if r['status'] in {'Approved','Declined','Needs information'}: raise HTTPException(409,'A decision is already recorded. Attach revised evidence before reanalysis.')
        revision=r['revision']; data=json.loads(r['data']); docs=[json.loads(d['data']) for d in c.execute('SELECT data FROM documents WHERE case_id=?',(id,))]
    result=analyze(data,docs); result['analyzed_revision']=revision; result['policy_version']='coursework-demo-v1'; result['created_at']=now()
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            updated=c.execute("UPDATE cases SET analysis=?,status='In review',updated_at=? WHERE id=? AND revision=? AND status NOT IN ('Approved','Declined','Needs information')",(json.dumps(result),now(),id,revision))
            if updated.rowcount!=1: raise HTTPException(409,'The application changed or a decision was recorded during analysis. Reload before continuing.')
            event(c,id,'analysis_completed',{'revision':revision,'blocking_findings':sum(f['blocking'] for f in result['findings']),'orchestrator':result['orchestrator']}); c.execute('COMMIT')
        except Exception: c.execute('ROLLBACK'); raise
    return result
@app.post('/cases/{id}/decision',dependencies=[Depends(authorize)])
def decide(id:str,payload:Decision):
    if len(payload.reviewer.strip())<2 or len(payload.note.strip())<10: raise HTTPException(422,'A named reviewer and a reason of at least 10 characters are required.')
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            r=row_case(c,id)
            if r['revision']!=payload.revision: raise HTTPException(409,'Application changed. Reload and review the latest version.')
            if not r['analysis']: raise HTTPException(409,'Run the analysis before recording a decision.')
            analysis=json.loads(r['analysis'])
            if analysis.get('analyzed_revision')!=r['revision']: raise HTTPException(409,'Analysis is stale. Run it again.')
            if payload.decision=='Approved' and any(f['blocking'] for f in analysis['findings']): raise HTTPException(409,'Approval blocked. Resolve evidence and policy findings first.')
            if r['status'] in {'Approved','Declined','Needs information'}: raise HTTPException(409,'A decision is already recorded. Attach revised evidence and reanalyze before changing it.')
            c.execute('UPDATE cases SET status=?,updated_at=? WHERE id=?',(payload.decision,now(),id)); event(c,id,'human_decision',payload.model_dump()); c.execute('COMMIT')
        except Exception: c.execute('ROLLBACK'); raise
        return render_case(c,row_case(c,id))
@app.post('/research',dependencies=[Depends(authorize)])
async def ask(payload:Question):
    try: return await research(payload.question)
    except ValueError as e: raise HTTPException(422,str(e))

# Serve the bundled dashboard and same-origin Python API adapter.
import sys
from local_frontend import register_frontend
register_frontend(app, sys.modules[__name__])
