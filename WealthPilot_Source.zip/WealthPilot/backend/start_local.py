"""Run with the venv Python; opens the local dashboard automatically."""
import socket, threading, webbrowser
import uvicorn

def available_port():
    for port in range(8000,8011):
        with socket.socket() as sock:
            try: sock.bind(('127.0.0.1',port));return port
            except OSError: continue
    raise SystemExit('Ports 8000-8010 are occupied. Stop an old WealthPilot server, then try again.')

if __name__=='__main__':
    port=available_port();url=f'http://127.0.0.1:{port}/'
    print(f'\nWealthPilot frontend: {url}\nKeep this terminal open. Press Ctrl+C to stop.\n',flush=True)
    threading.Timer(2.0,lambda:webbrowser.open(url)).start()
    uvicorn.run('app:app',host='127.0.0.1',port=port)
