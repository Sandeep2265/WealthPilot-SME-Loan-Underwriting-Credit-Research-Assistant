# WealthPilot portable Python service

This service is the portable backend for the coursework project. It serves a bundled local React dashboard at `/` and API documentation at `/docs`. The online Site remains a separate deployment. It provides a real FastAPI service, SQLite persistence, evidence parsing, deterministic credit analysis, a LangGraph workflow when installed, policy retrieval, an optional LLM research adapter, and an MCP stdio server.

## Run on Fedora / Linux / macOS

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/` for the frontend dashboard. Open `/docs` for API testing. On Windows, double-click `START_WEALTHPILOT.bat` in the project root, or run `python start_local.py` from this backend folder with the virtual environment active. The launcher chooses a free local port and opens the browser automatically. No Node.js install is needed for the bundled frontend. `GET /health` indicates the runtime mode. SQLite is created in `backend/data/`; set `WEALTHPILOT_DB` to use another durable path. Back up this file and its WAL safely. No real borrower documents are included: examples are synthetic.

For remote deployment, configure a strong random `WEALTHPILOT_API_TOKEN`, serve behind HTTPS, restrict `CORS_ORIGINS`, and send `Authorization: Bearer ...` from a trusted server adapter. Never put this shared service token into public frontend source. Without a token the API rejects remote client addresses. Local no-token mode is for development only. The token is shared-service authentication, not per-reviewer role enforcement; reviewer names are recorded assertions, not verified identities. Production use requires verified user identities, reviewer roles, encryption/key management, retention controls and bank-approved credit policy.

## Pipeline and decision gate

1. **Document analyst** parses UTF-8 TXT/CSV and text-based PDFs; validates size/type and rejects unreadable or encrypted content; hashes documents for duplicate detection. Extracts strict labeled financial fields. Unrecognized formatting is flagged as missing evidence rather than guessed. Scanned PDFs require external OCR.
2. **Financial analyst** reconciles every entered value with supporting evidence and computes DSCR, debt/equity and current ratio. Missing, nonfinite, negative or zero-denominator inputs generate review findings. Ratio thresholds are deterministic and calculated before display rounding.
3. **Policy researcher** retrieves versioned coursework policies using 256-dimensional local hashed term vectors with cosine similarity. This is vector retrieval, not neural semantic embeddings; it does not require an external API and is not described as a trained credit model.
4. **Risk and fairness reviewer** excludes protected traits from credit calculations, flags suspected instruction injection, and collects unresolved findings. This is input exclusion and rule evaluation, not statistical fairness certification.
5. **Credit coordinator** returns either `Needs review` or `Eligible for human review`. A human reviewer must supply a name and substantive reason. Approval is blocked while any blocking finding remains. Case revisions invalidate previous analyses, and stale/concurrent decisions are rejected.

These specialized nodes run through `StateGraph` in LangGraph when installed. If the optional dependency is absent, the same nodes execute sequentially and explicitly report the fallback orchestrator. No LLM is used to perform arithmetic or make autonomous approval decisions. API audit events record upload, analysis, input changes and human decisions. They persist in SQLite; they are ordinary audit records, not a tamper-proof ledger.

## Test an application

```bash
curl -X POST http://127.0.0.1:8000/cases \
  -H 'Content-Type: application/json' --data-binary @samples/case.json
```

Copy the returned application ID into the following requests:

- `POST /cases/{id}/documents`: multipart field `file`; attach `samples/financials.txt`.
- `POST /cases/{id}/analyze`: returns metrics, policy evidence, findings and agent trace.
- `GET /cases/{id}`: returns the latest revision, analysis, document metadata and audit history.
- `POST /cases/{id}/decision`: JSON `{"decision":"Approved","reviewer":"Your Name","note":"Reviewed financial evidence and policy results.","revision":2}`. Use the actual latest revision. Decisions: `Approved`, `Declined`, `Needs information`.
- `PATCH /cases/{id}?revision=2`: full case JSON, for corrected entered values; invalidates prior analysis.
- `DELETE /cases/{id}/documents/{document_id}?revision=2`: remove incorrect evidence; invalidates analysis and records removal.
- `GET /cases`: lists up to the latest 500 applications.
- `GET /policies`: versioned demo policy corpus.
- `POST /research`: JSON `{"question":"What is the minimum debt service coverage?"}`.

All financial amounts use the selected currency's base units consistently (rupees for INR), for the same annual period. Supported labels are `revenue`, `operating_cash_flow`, `debt_service`, `total_debt`, `equity`, `current_assets`, `current_liabilities`. Use one `field: number` or `field,number` per line. Exact sample formatting is provided. All matched values must reconcile; multiple conflicting values produce review findings. The borrower name and sector do not enter the ratio calculations. Sector-specific policy, tax verification and external bureau research are outside this demonstration.

## Optional LLM research

Set these variables in your process environment; do not commit them:

- `LLM_API_KEY`: provider credential.
- `LLM_MODEL`: an installed/available model supporting chat completions and JSON mode.
- `LLM_BASE_URL`: defaults to `https://api.openai.com/v1`.

The research adapter retrieves policy excerpts, asks for a citation-bearing JSON answer, applies a 25-second request timeout and one retry, validates cited policy IDs and citation markers, and falls back to literal retrieved passages on errors. Without credentials it explicitly reports `retrieval-only`. Citation validation does **not** prove semantic entailment; a reviewer must verify generated claims. Only submitted research text and policy excerpts are sent to the configured provider by `/research`; uploaded documents are not automatically sent. Prompt-injection detection is a heuristic and cannot guarantee malicious-content detection.

## MCP tools

```bash
python mcp_server.py
```

Connect this process as a stdio MCP server. It exposes `search_policy`, `calculate_credit_metrics`, and the `wealthpilot://policy/demo-v1` policy resource. It deliberately exposes no human-approval mutation tool. The SDK handles JSON-RPC and stdio framing.

## Verification

```bash
python -m unittest test_backend -v
```

Tests cover valid and boundary ratios; missing, negative, nonfinite and zero-denominator values; missing/conflicting evidence; duplicate documents; suspected prompt injection; protected-trait invariance; malformed uploads; policy retrieval; retrieval-only research; API validation; token authentication; stale decisions; approval gating and repeated final decisions. API tests use temporary SQLite storage. LangGraph routing is additionally exercised when installed. Live LLM provider calls and production user authentication are not covered without configured services.

## Local dashboard API adapter

`local_frontend.py` exposes `/api/*` on the same Python server, converting dashboard inputs in INR lakhs to backend base rupees. The local dashboard uses **operating cash flow**, not EBITDA, for DSCR and uses the Python policy liquidity threshold of **1.20**. Source-document values must be in INR rupees and use the Python snake_case labels. The CSV template in the local UI uses these labels/units. Unambiguous recognized source values populate missing financial inputs; conflicting values never silently replace entered inputs. PDF download controls return extracted text, not the original PDF bytes. `years` is saved for display and is not a criterion in the current portable policy.

The frontend is prebuilt in `static/`. To rebuild it after UI edits, from the project root run `npm ci` followed by `node frontend/build.mjs`. This generates `frontend/Dashboard.tsx` from the hosted dashboard with portable-mode labels and produces the static assets. Python alone serves the packaged assets.

Adapter regression tests: `python -m unittest -v test_local_frontend.py`.
