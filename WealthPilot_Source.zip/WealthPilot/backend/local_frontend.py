"""Same-origin adapter between the bundled dashboard and portable credit API.
UI monetary inputs are INR lakh; portable API and evidence are INR rupees.
"""
from __future__ import annotations
import json, math, re, sys
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from engine import POLICIES, FIELDS

MAP={'revenue':'revenue','ebitda':'operating_cash_flow','debtService':'debt_service','currentAssets':'current_assets','currentLiabilities':'current_liabilities','totalDebt':'total_debt','equity':'equity'}
FINAL={'Approved','Declined'}

def register_frontend(app, core):
    router=APIRouter(prefix='/api',dependencies=[Depends(core.authorize)])
    def load(id):
        with core.db() as conn:
            r=core.row_case(conn,id); raw=core.render_case(conn,r)
            raw['documents']=[json.loads(d['data'])|{'id':d['id']} for d in conn.execute('SELECT * FROM documents WHERE case_id=?',(id,))]
            return raw
    def out(raw):
        f=raw.get('financials',{}); docs=raw.get('documents',[]); a=raw.get('analysis'); analysis=None
        ui_docs=[]
        for d in docs:
            conflicts=[k.replace('_',' ')+' conflicts with entered evidence' for k,vals in d.get('facts',{}).items() if f.get(k) is not None and any(abs(v-f[k])>max(.01,abs(f[k])*.00001) for v in vals)]
            if d.get('suspicious'): conflicts.append('Potential document instruction injection detected.')
            ui_docs.append({'id':d['id'],'name':d['name'],'size':d.get('bytes',0),'uploadedAt':raw['updated_at'],'status':'Conflict' if conflicts else 'Parsed','text':d.get('text','')[:12000],'conflicts':conflicts})
        if a:
            findings=a.get('findings',[]); blockers=[f['message'] for f in findings if f.get('blocking')]
            coverage=round(sum(f.get(k) is not None for k in FIELDS)/len(FIELDS)*100)
            m=a.get('metrics',{}); trace=a.get('trace',[])
            checks=[{'id':str(i),'label':x['code'].replace('_',' ').capitalize(),'status':'fail' if x.get('blocking') else 'warn','detail':x['message'],'source':x['policy']+(' · '+', '.join(x.get('sources',[])) if x.get('sources') else '')} for i,x in enumerate(findings)]
            for name,value,ok,policy in [('Debt service coverage',m.get('dscr'),lambda v:v>=1.25,'POL-01'),('Current ratio',m.get('current_ratio'),lambda v:v>=1.2,'POL-03'),('Debt / equity',m.get('debt_to_equity'),lambda v:v<=3,'POL-02')]:
                if value is not None and ok(value): checks.append({'id':name,'label':name,'status':'pass','detail':f'{value:.2f}× meets the configured policy.','source':policy})
            if not blockers: checks.append({'id':'evidence','label':'Evidence reconciled','status':'pass','detail':'All seven fields match their labeled document evidence. A human must verify authenticity and reporting period.','source':'POL-04'})
            analysis={'recommendation':a['recommendation'],'summary':f'{len(blockers)} unresolved findings. '+('Review evidence and resolve findings before approval.' if blockers else 'Evidence reconciles and configured financial checks pass. Human approval is still required.'),'coverage':coverage,'risk':'Unrated' if coverage<100 else 'High' if blockers else 'Low','ratios':{'dscr':m.get('dscr'),'currentRatio':m.get('current_ratio'),'debtToEquity':m.get('debt_to_equity'),'ebitdaMargin':f.get('operating_cash_flow')/f['revenue'] if f.get('operating_cash_flow') is not None and (f.get('revenue') or 0)>0 else None},'checks':checks,'agents':[{'name':t['agent'],'status':'Completed' if not blockers or t['agent'] not in ['Document analyst','Credit coordinator'] else 'Needs attention','detail':t['detail']} for t in trace]+[{'name':'Human approval gate','status':'Completed' if raw['status'] in FINAL else 'Awaiting reviewer','detail':'Recorded decision available in the audit trail.' if raw['status'] in FINAL else 'Reviewer name and rationale are required.'}],'blockers':blockers,'policyVersion':a.get('policy_version','coursework-demo-v1'),'completedAt':a.get('created_at'),'orchestrator':a.get('orchestrator','Unknown'),'mode':'Local Python service','strengths':[],'risks':blockers}
        return {'id':raw['id'],'company':raw['company'],'industry':raw['sector'],'amount':raw['loan_amount']/100000,'purpose':raw['purpose'],'years':raw.get('years'),'financials':{k:f.get(v)/100000 if f.get(v) is not None else None for k,v in MAP.items()},'status':{'In review':'Needs review','Needs information':'More information'}.get(raw['status'],raw['status']),'documents':ui_docs,'analysis':analysis,'createdAt':raw['created_at'],'updatedAt':raw['updated_at'],'version':raw['revision'],'demo':raw.get('company','').startswith('Demo ·')}
    def payload(body):
        try:
            money={v:float(body[k])*100000 if body.get(k) is not None else None for k,v in MAP.items()}
            return core.CaseInput(company=body.get('company',''),sector=body.get('industry',''),loan_amount=float(body.get('amount',0))*100000,currency='INR',purpose=body.get('purpose',''),years=body.get('years'),financials=money)
        except (ValueError,TypeError) as exc: raise HTTPException(422,str(exc))
    async def read_body(req):
        raw=b''
        async for chunk in req.stream():
            raw+=chunk
            if len(raw)>20000: raise HTTPException(413,'Request exceeds 20 KB.')
        try:
            value=json.loads(raw)
            if not isinstance(value,dict): raise ValueError()
            return value
        except (ValueError,TypeError): raise HTTPException(400,'Provide a valid JSON object.')
    def mutable(raw):
        if raw['status'] in FINAL: raise HTTPException(409,'Final decisions are locked. Create a new application for reassessment.')
    @router.get('/workspace')
    def workspace():
        with core.db() as conn:
            ids=[r['id'] for r in conn.execute('SELECT id FROM cases ORDER BY updated_at DESC LIMIT 500')]
            audit=[{'id':r['id'],'caseId':r['case_id'],'action':r['event'].replace('_',' '),'detail':json.dumps(json.loads(r['data']),ensure_ascii=False),'actor':json.loads(r['data']).get('reviewer','System'),'createdAt':r['created_at']} for r in conn.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 500')]
        return {'cases':[out(load(id)) for id in ids],'policies':[dict(p,category='Coursework policy',version='demo-v1') for p in POLICIES],'audit':audit,'mode':'Local Python service'}
    @router.post('/demo')
    def demo():
        # Explicitly empty: local user data is never silently populated.
        return {'ok':True,'message':'Local workspace ready. Create your first application.'}
    @router.post('/cases')
    async def create(req:Request): return {'case':out(load(core.create_case(payload(await read_body(req)))['id']))}
    @router.get('/cases/{id}')
    def get(id:str): return {'case':out(load(id))}
    @router.patch('/cases/{id}')
    async def patch(id:str,req:Request):
        body=await read_body(req);raw=load(id);mutable(raw)
        try: version=int(body['version'])
        except (KeyError,TypeError,ValueError): raise HTTPException(422,'Current application version is required.')
        core.update_case(id,payload(body),version)
        return {'case':out(load(id))}
    @router.post('/cases/{id}/analyze')
    def run(id:str):
        core.run_analysis(id);return {'case':out(load(id))}
    @router.post('/cases/{id}/documents')
    async def attach(id:str,file:UploadFile=File(...)):
        mutable(load(id));await core.upload(id,file);return {'case':out(load(id))}
    @router.get('/cases/{id}/documents/{docId}')
    def document(id:str,docId:str):
        raw=load(id);d=next((d for d in raw['documents'] if d['id']==docId),None)
        if not d: raise HTTPException(404,'Document not found.')
        # PDF sources are extracted text; always name downloads honestly.
        name=re.sub(r'[^a-zA-Z0-9_.-]','_',d['name'])+'.extracted.txt'
        return Response(d.get('text',''),media_type='text/plain',headers={'Content-Disposition':f'attachment; filename="{name}"','X-Content-Type-Options':'nosniff'})
    @router.delete('/cases/{id}/documents/{docId}')
    def remove(id:str,docId:str,version:int):
        mutable(load(id));core.remove_document(id,docId,version);return {'case':out(load(id))}
    @router.post('/cases/{id}/decision')
    async def decide(id:str,req:Request):
        b=await read_body(req)
        try: decision=core.Decision(decision={'More information':'Needs information'}.get(b.get('decision'),b.get('decision')),reviewer=b.get('reviewer',''),note=b.get('note',''),revision=b.get('version'))
        except ValueError as exc: raise HTTPException(422,str(exc))
        core.decide(id,decision);return {'case':out(load(id))}
    @router.post('/research')
    async def research(req:Request):
        b=await read_body(req);return await core.ask(core.Question(question=b.get('question','')))
    app.include_router(router)
    static=Path(__file__).parent/'static'
    if (static/'index.html').exists():
        app.mount('/assets',StaticFiles(directory=static/'assets'),name='frontend-assets')
        @app.get('/',include_in_schema=False)
        def frontend(): return FileResponse(static/'index.html',headers={'Cache-Control':'no-store'})
