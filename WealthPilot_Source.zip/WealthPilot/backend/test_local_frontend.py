"""Regression tests for the packaged browser dashboard and same-origin adapter."""
import importlib, os, tempfile, unittest
from fastapi.testclient import TestClient

class LocalFrontendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        os.environ['WEALTHPILOT_DB']=cls.tmp.name+'/local.sqlite3'
        os.environ.pop('WEALTHPILOT_API_TOKEN',None)
        import app
        cls.core=app
        cls.core.DB_PATH=os.environ['WEALTHPILOT_DB']
        cls.core.initialize()
        cls.client=TestClient(app.app)
    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()
        os.environ.pop('WEALTHPILOT_DB',None)
    def create(self,**overrides):
        data={'company':'Local Test Business','industry':'Manufacturing','amount':50,'purpose':'Expand machining capacity','years':5,'revenue':420,'ebitda':65,'debtService':40,'currentAssets':140,'currentLiabilities':70,'totalDebt':120,'equity':80}
        data.update(overrides)
        r=self.client.post('/api/cases',json=data)
        self.assertEqual(r.status_code,200,r.text)
        return r.json()['case']
    def test_root_serves_dashboard(self):
        r=self.client.get('/')
        self.assertEqual(r.status_code,200)
        self.assertIn('id="root"',r.text)
        self.assertEqual(self.client.get('/assets/dashboard.js').status_code,200)
        self.assertEqual(self.client.get('/assets/dashboard.css').status_code,200)
    def test_unit_conversion_and_reconciliation(self):
        c=self.create(); id=c['id']
        self.assertEqual(c['financials']['ebitda'],65)
        self.assertEqual(self.client.get('/cases/'+id).json()['financials']['operating_cash_flow'],6500000)
        self.assertEqual(c['years'],5)
        doc='revenue,42000000\noperating_cash_flow,6500000\ndebt_service,4000000\ncurrent_assets,14000000\ncurrent_liabilities,7000000\ntotal_debt,12000000\nequity,8000000'
        up=self.client.post('/api/cases/'+id+'/documents',files={'file':('financials.csv',doc,'text/csv')})
        self.assertEqual(up.status_code,200,up.text)
        c=up.json()['case'];d=c['documents'][0]
        self.assertEqual(self.client.get(f'/api/cases/{id}/documents/{d["id"]}').text,doc)
        result=self.client.post('/api/cases/'+id+'/analyze');self.assertEqual(result.status_code,200,result.text)
        c=result.json()['case'];a=c['analysis']
        self.assertEqual(a['blockers'],[])
        self.assertEqual(a['ratios']['dscr'],1.625)
        self.assertEqual(a['orchestrator'],'LangGraph')
        decision={'decision':'Approved','reviewer':'QA Reviewer','note':'Verified synthetic document evidence and all policy checks.','version':c['version']}
        self.assertEqual(self.client.post('/api/cases/'+id+'/decision',json=decision).status_code,200)
        self.assertEqual(self.client.patch('/api/cases/'+id,json={'version':c['version']}).status_code,409)
        self.assertEqual(self.client.delete(f'/api/cases/{id}/documents/{d["id"]}?version={c["version"]}').status_code,409)
    def test_missing_data_blocks_and_stale_versions_rejected(self):
        c=self.create(revenue=None,ebitda=None);id=c['id']
        a=self.client.post(f'/api/cases/{id}/analyze').json()['case']['analysis']
        self.assertIsNone(a['ratios']['ebitdaMargin']);self.assertTrue(a['blockers'])
        r=self.client.post(f'/api/cases/{id}/decision',json={'decision':'Approved','reviewer':'QA Reviewer','note':'Test must reject missing financial and source evidence.','version':c['version']})
        self.assertEqual(r.status_code,409)
        r=self.client.patch(f'/api/cases/{id}',json={'version':c['version']+1,'company':'Local Test Business','industry':'Manufacturing','amount':50,'purpose':'Expand machining capacity'})
        self.assertEqual(r.status_code,409)
    def test_workspace_and_research(self):
        r=self.client.get('/api/workspace');self.assertEqual(r.status_code,200)
        self.assertIn('cases',r.json());self.assertEqual(len(r.json()['policies']),5)
        r=self.client.post('/api/research',json={'question':'debt service coverage'})
        self.assertEqual(r.status_code,200);self.assertTrue(r.json()['sources'])
    def test_invalid_json_and_wrong_currency_source(self):
        self.assertEqual(self.client.post('/api/cases',content='invalid').status_code,400)
        c=self.create();id=c['id']
        self.client.post(f'/api/cases/{id}/documents',files={'file':('wrong-units.csv','revenue,420\noperating_cash_flow,65','text/csv')})
        a=self.client.post(f'/api/cases/{id}/analyze').json()['case']['analysis']
        self.assertTrue(any('conflict' in b for b in a['blockers']))

if __name__=='__main__':unittest.main()
