"""Run: python mcp_server.py. Uses stdio; no unauthenticated network listener."""
from mcp.server.fastmcp import FastMCP
from engine import POLICIES, analyze, retrieve
mcp=FastMCP('WealthPilot credit research')
@mcp.tool()
def search_policy(query:str)->dict:
    """Retrieve demo credit policy with local hashed-vector cosine search."""
    return {'version':'coursework-demo-v1','sources':retrieve(query)}
@mcp.tool()
def calculate_credit_metrics(financials:dict)->dict:
    """Advisory deterministic ratios. Missing source evidence blocks approval."""
    result=analyze({'financials':financials},[])
    return {'metrics':result['metrics'],'findings':result['findings'],'recommendation':result['recommendation']}
@mcp.resource('wealthpilot://policy/demo-v1')
def policy_resource()->str:
    import json
    return json.dumps(POLICIES)
if __name__=='__main__': mcp.run(transport='stdio')
