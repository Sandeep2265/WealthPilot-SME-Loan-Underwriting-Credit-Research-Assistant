import { analyzeCase, metricKeys, type CreditCase } from './underwriting';
export function sampleCases():CreditCase[]{
 const now=new Date().toISOString();const rows=[
 {id:'sample-aster',company:'Aster Precision Pvt Ltd',industry:'Manufacturing',amount:75,purpose:'Expand precision machining capacity',years:8,revenue:420,ebitda:86,debtService:48,currentAssets:186,currentLiabilities:104,totalDebt:180,equity:148},
 {id:'sample-verdant',company:'Verdant Foods',industry:'Food & beverage',amount:40,purpose:'Seasonal inventory and working capital',years:5,revenue:240,ebitda:38,debtService:36,currentAssets:92,currentLiabilities:96,totalDebt:120,equity:44},
 {id:'sample-northstar',company:'Northstar Logistics',industry:'Logistics',amount:120,purpose:'Fleet electrification and route expansion',years:4,revenue:600,ebitda:110,debtService:62,currentAssets:208,currentLiabilities:140,totalDebt:210,equity:120},
 {id:'sample-loom',company:'Loom & Co',industry:'Textiles',amount:25,purpose:'Purchase looms and raw materials',years:1,revenue:95,ebitda:null,debtService:null,currentAssets:40,currentLiabilities:32,totalDebt:45,equity:20}
 ];return rows.map((r,i)=>{const financials=Object.fromEntries(metricKeys.map(k=>[k,r[k]])) as CreditCase['financials'];const c:CreditCase={id:r.id,company:r.company,industry:r.industry,amount:r.amount,purpose:r.purpose,years:r.years,financials,status:'Needs review',documents:i===3?[]:[{id:`sample-doc-${i}`,name:`${r.company.split(' ')[0]}_financials_FY2026.csv`,size:230,uploadedAt:now,status:'Parsed',text:metricKeys.map(k=>`${k},${r[k]}`).join('\n'),conflicts:[],key:''}],analysis:null,createdAt:now,updatedAt:now,version:1,demo:true};c.analysis=analyzeCase(c);return c;});
}
