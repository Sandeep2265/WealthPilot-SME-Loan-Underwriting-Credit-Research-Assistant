import { env } from 'cloudflare:workers';
import { z } from 'zod';
import type { CreditCase } from './underwriting';
export class ApiError extends Error { constructor(public status:number,message:string){super(message);} }
export const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function guard(fn:()=>Promise<Response>){try{return await fn();}catch(e){if(e instanceof ApiError)return json({error:e.message},e.status);if(e instanceof z.ZodError)return json({error:e.issues.map(x=>`${x.path.join('.')}: ${x.message}`).join('; ')},400);console.error('WealthPilot API error', e instanceof Error?e.message:'Unknown error');return json({error:'The workspace could not complete this request. Please retry.'},503);}}
export function database(){if(!env.DB)throw new ApiError(503,'Workspace storage is unavailable. Please retry later.');return env.DB;}
export function assertSameOrigin(req:Request){const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)throw new ApiError(403,'Cross-origin changes are not allowed.');}
export async function readBounded(req:Request,max:number){
 const length=Number(req.headers.get('content-length')||0);if(length>max)throw new ApiError(413,'Request is too large.');
 if(!req.body)return new Uint8Array();const reader=req.body.getReader(),chunks:Uint8Array[]=[];let size=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>max){await reader.cancel();throw new ApiError(413,'Request is too large.');}chunks.push(value);}}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.byteLength;}return bytes;
}
export async function body(req:Request){assertSameOrigin(req);const raw=new TextDecoder().decode(await readBounded(req,20000));try{return JSON.parse(raw);}catch{throw new ApiError(400,'Please provide valid JSON.');}}

export async function getCase(id:string){const row=await database().prepare('SELECT data FROM credit_cases WHERE id=?').bind(id).first<{data:string}>();if(!row)throw new ApiError(404,'Application not found.');return JSON.parse(row.data) as CreditCase;}
export function event(caseId:string|null,action:string,detail:string,actor='System'){return {id:crypto.randomUUID(),caseId,action,detail,actor,createdAt:new Date().toISOString()};}
export async function createCase(c:CreditCase,actor='Analyst'){const e=event(c.id,'Application created',`${c.company} • ₹${c.amount} lakh requested.`,actor);await database().batch([database().prepare('INSERT INTO credit_cases (id,data,version,updated_at) VALUES (?,?,?,?)').bind(c.id,JSON.stringify(c),c.version,c.updatedAt),database().prepare('INSERT INTO credit_audit (id,case_id,action,detail,actor,created_at) VALUES (?,?,?,?,?,?)').bind(e.id,e.caseId,e.action,e.detail,e.actor,e.createdAt)]);}
export async function updateCase(c:CreditCase,expected:number,action:string,detail:string,actor='System'){
 c.version=expected+1;c.updatedAt=new Date().toISOString();const e=event(c.id,action,detail,actor);const result=await database().batch([database().prepare('UPDATE credit_cases SET data=?,version=?,updated_at=? WHERE id=? AND version=?').bind(JSON.stringify(c),c.version,c.updatedAt,c.id,expected),database().prepare('INSERT INTO credit_audit (id,case_id,action,detail,actor,created_at) SELECT ?,?,?,?,?,? WHERE changes()=1').bind(e.id,e.caseId,e.action,e.detail,e.actor,e.createdAt)]);if(result[0].meta.changes!==1)throw new ApiError(409,'This application changed while you were working. Refresh and review the latest version.');return c;
}
export const numberField=z.number().finite().min(0).max(1e12).nullable().optional().transform(v=>v??null);
export const createSchema=z.object({company:z.string().trim().min(2).max(120),industry:z.string().trim().min(2).max(80),amount:z.number().finite().positive().max(1e9),purpose:z.string().trim().min(3).max(500),years:z.number().finite().min(0).max(200).nullable().optional().transform(v=>v??null),revenue:numberField,ebitda:z.number().finite().min(-1e12).max(1e12).nullable().optional().transform(v=>v??null),debtService:numberField,currentAssets:numberField,currentLiabilities:numberField,totalDebt:numberField,equity:z.number().finite().min(-1e12).max(1e12).nullable().optional().transform(v=>v??null)}).strict();
