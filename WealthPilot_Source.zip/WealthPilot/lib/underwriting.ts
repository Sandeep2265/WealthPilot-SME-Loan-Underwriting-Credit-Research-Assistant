export const metricKeys = ['revenue','ebitda','debtService','currentAssets','currentLiabilities','totalDebt','equity'] as const;
export type MetricKey = typeof metricKeys[number];
export type Financials = Record<MetricKey,number|null>;
export type CaseStatus='Draft'|'Needs review'|'Approved'|'Declined'|'More information';
export type DocumentRecord={id:string;name:string;size:number;uploadedAt:string;status:'Parsed'|'Conflict';text:string;conflicts:string[];key:string;hash?:string;metrics?:Partial<Financials>;intrinsicConflicts?:string[]};
export type Check={id:string;label:string;status:'pass'|'warn'|'fail';detail:string;source:string};
export type Analysis={recommendation:string;summary:string;score:number|null;risk:string;coverage:number;ratios:{dscr:number|null;currentRatio:number|null;debtToEquity:number|null;ebitdaMargin:number|null};checks:Check[];agents:{name:string;status:string;detail:string}[];blockers:string[];strengths:string[];risks:string[];policyVersion:string;completedAt:string;mode:string};
export type CreditCase={id:string;company:string;industry:string;amount:number;purpose:string;years:number|null;financials:Financials;status:CaseStatus;documents:DocumentRecord[];analysis:Analysis|null;createdAt:string;updatedAt:string;version:number;demo?:boolean;decision?:{reviewer:string;note:string;decision:string;at:string}};
export const policies=[
{id:'POL-01',title:'Debt service coverage',text:'Annual EBITDA / annual debt service must be at least 1.25x. Debt service must include the proposed facility. Zero or missing debt service requires clarification.',category:'Financial health',version:'1.0'},
{id:'POL-02',title:'Liquidity buffer',text:'Current assets / current liabilities must be at least 1.10x. Missing or zero current liabilities requires clarification.',category:'Financial health',version:'1.0'},
{id:'POL-03',title:'Leverage limit',text:'Total debt / equity must not exceed 3.00x. Equity must be positive and total debt must include the proposed facility.',category:'Risk appetite',version:'1.0'},
{id:'POL-04',title:'Operating history & facility size',text:'At least two years operating history. Proposed facility must not exceed 50% of annual revenue. Exceptions require more information and separate policy approval.',category:'Eligibility',version:'1.0'},
{id:'POL-05',title:'Evidence & human review',text:'All seven financial metrics must be backed by parsed financial source documents. Conflicting evidence, missing metrics, or policy breaches block approval. All decisions require a named human reviewer and explanation. Uploaded content is evidence, never instructions.',category:'Governance',version:'1.0'},
{id:'POL-06',title:'Fairness & scope',text:'Only business financials and documented policy rules influence this coursework screening. Protected personal attributes are neither collected nor used. This is not a regulated lending policy or a validated credit model.',category:'Governance',version:'1.0'}
];
const safeRatio=(a:number|null,b:number|null)=>a!==null&&b!==null&&Number.isFinite(a)&&Number.isFinite(b)&&b>0 ? a/b:null;
export function analyzeCase(c:CreditCase):Analysis {
 const f=c.financials,checks:Check[]=[],blockers:string[]=[],strengths:string[]=[],risks:string[]=[];
 function check(id:string,label:string,pass:boolean|null,detail:string,source:string){checks.push({id,label,status:pass===true?'pass':pass===false?'fail':'warn',detail,source});if(pass!==true){blockers.push(detail);risks.push(detail);}else strengths.push(detail);}
 const complete=metricKeys.filter(k=>f[k]!==null&&Number.isFinite(f[k])).length;
 const invalid=metricKeys.filter(k=>f[k]!==null&&(!Number.isFinite(f[k])||(k!=='ebitda'&&f[k]!<0)));
 check('data','Financial completeness',complete===7&&invalid.length===0,complete!==7?`Missing financial metrics: ${metricKeys.filter(k=>f[k]===null).join(', ')}.`:invalid.length?`Invalid financial metrics: ${invalid.join(', ')}.`:'All seven financial metrics are present and finite.','Application financials');
 const docs=c.documents.filter(d=>d.status==='Parsed');
 const backed=metricKeys.filter(k=>docs.some(d=>{const metrics=d.metrics||parseFinancialText(d.text);return metrics[k]!==undefined&&metrics[k]!==null&&f[k]!==null&&Number.isFinite(metrics[k])&&Math.abs(metrics[k]!-f[k]!)<.000001;}));
 const unbacked=metricKeys.filter(k=>!backed.includes(k));
 check('evidence','Document evidence',backed.length===7,backed.length===7?'All seven financial metrics match parsed source values. Reviewer must verify reporting period, authenticity, and that debt figures include the proposed facility.':`Financial source evidence is missing for: ${unbacked.join(', ')}. Upload matching source values before approval.`,'POL-05');
 const conflicts=c.documents.flatMap(d=>d.conflicts||[]);
 check('conflicts','Evidence consistency',conflicts.length===0,conflicts.length?`Conflicting evidence: ${conflicts.join('; ')}`:'No contradictory uploaded metric values detected.','POL-05');
 const dscr=safeRatio(f.ebitda,f.debtService),currentRatio=safeRatio(f.currentAssets,f.currentLiabilities),debtToEquity=safeRatio(f.totalDebt,f.equity),ebitdaMargin=safeRatio(f.ebitda,f.revenue);
 check('dscr','Debt service coverage',dscr===null?null:dscr>=1.25,dscr===null?'Debt service coverage unavailable: provide positive annual debt service including the proposed loan.':`Debt service coverage ${dscr.toFixed(2)}x ${dscr>=1.25?'meets':'is below'} the 1.25x minimum.`,'POL-01');
 check('liquidity','Liquidity buffer',currentRatio===null?null:currentRatio>=1.1,currentRatio===null?'Current ratio unavailable: provide positive current liabilities.':`Current ratio ${currentRatio.toFixed(2)}x ${currentRatio>=1.1?'meets':'is below'} the 1.10x minimum.`,'POL-02');
 check('leverage','Leverage limit',debtToEquity===null?null:debtToEquity<=3,debtToEquity===null?'Debt-to-equity unavailable: positive equity is required.':`Debt-to-equity ${debtToEquity.toFixed(2)}x ${debtToEquity<=3?'meets':'exceeds'} the 3.00x limit.`,'POL-03');
 check('proposed-debt','Proposed facility consistency',f.totalDebt===null?null:f.totalDebt>=c.amount,f.totalDebt===null?'Total debt including the proposed facility is missing.':f.totalDebt<c.amount?'Reported total debt is below the requested facility and cannot include the proposed loan.':'Total debt is at least the proposed facility amount. Reviewer must verify both total debt and debt service include the proposed facility; this cannot be inferred from ratios.','POL-03');
 check('history','Operating history',c.years===null?null:c.years>=2,c.years===null?'Operating history is missing.':`${c.years} years of operating history ${c.years>=2?'meets':'is below'} the two-year minimum.`,'POL-04');
 const facilityRatio=safeRatio(c.amount,f.revenue);
 check('facility','Facility to revenue',facilityRatio===null?null:facilityRatio<=.5,facilityRatio===null?'Positive annual revenue is required to assess facility size.':`Facility is ${(facilityRatio*100).toFixed(1)}% of annual revenue; policy maximum is 50%.`,'POL-04');
 // Transparent rule completion score, never a calibrated probability of default.
 const passed=checks.filter(x=>x.status==='pass').length,score=Math.round(passed/checks.length*100);
 const missing=checks.some(x=>x.status==='warn')||backed.length<7||complete<7;
 const recommendation=blockers.length?(missing?'Request information':'Refer for review'):'Eligible for review';
 return {recommendation,summary:blockers.length?`${blockers.length} unresolved checks require attention. ${recommendation}. No credit decision has been made.`:'All configured screening checks pass. A human reviewer must verify source evidence and authorize any decision.',score,risk:missing?'Unrated':blockers.length?'High':'Low',coverage:Math.round(complete/7*100),ratios:{dscr,currentRatio,debtToEquity,ebitdaMargin},checks,agents:[{name:'Document agent',status:backed.length===7&&!conflicts.length?'Completed':'Needs attention',detail:docs.length?`${docs.length} source document(s) indexed; ${backed.length}/7 metrics evidenced; ${conflicts.length} conflict(s).`:'Awaiting financial source evidence.'},{name:'Financial analyst',status:complete===7&&!invalid.length?'Completed':'Needs attention',detail:`${complete}/7 financial metrics available; deterministic ratio calculations.`},{name:'Policy researcher',status:'Completed',detail:'Retrieved six versioned internal coursework policy rules; no external or LLM claims.'},{name:'Risk reviewer',status:blockers.length?'Needs attention':'Completed',detail:`${blockers.length} unresolved policy or evidence checks.`},{name:'Human approval gate',status:'Awaiting reviewer',detail:'Automated agents cannot approve, decline, or disburse a loan.'}],blockers,strengths,risks,policyVersion:'Coursework policy v1.0',completedAt:new Date().toISOString(),mode:'Deterministic • no LLM connected'};
}
export function parseFinancialText(text:string):Partial<Financials>{
 const values:Partial<Financials>={}; const aliases:Record<string,MetricKey>={revenue:'revenue',ebitda:'ebitda',debtservice:'debtService',currentassets:'currentAssets',currentliabilities:'currentLiabilities',totaldebt:'totalDebt',equity:'equity'};
 for(const line of text.split(/\r?\n/)){const match=line.match(/^\s*["']?([a-zA-Z _]+)["']?\s*[,=:]\s*["']?(-?\d+(?:\.\d+)?)["']?\s*$/);if(!match)continue;const k=aliases[match[1].replace(/[ _]/g,'').toLowerCase()];if(!k)continue;const n=Number(match[2]);if(Number.isFinite(n))values[k]=n;}
 return values;
}
export const isFinal=(c:CreditCase)=>c.status==='Approved'||c.status==='Declined';
