# Start WealthPilot locally (Windows)

1. Extract the ZIP into a new folder.
2. Open the inner `WealthPilot` folder.
3. Double-click **START_WEALTHPILOT.bat**. It uses/creates `backend/.venv`, installs missing dependencies and opens your local dashboard automatically.
4. Keep the terminal open. Use Ctrl+C to stop it.

The frontend and Python backend now run together. The default address is `http://127.0.0.1:8000/`; if that port is occupied, the launcher selects the next available port and prints/opens the correct address. `/docs` remains the API testing page.

If you already have the old server running, stop it with Ctrl+C before starting this updated package. Extracting a fresh ZIP does not move existing SQLite data: to preserve records, copy `backend/data/` from the old installation into the new one while both servers are stopped.

Manual PowerShell commands from this project's `backend` folder:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe start_local.py
```

No PowerShell activation command or Node.js installation is needed to run the packaged frontend. Python must already be installed. The local dashboard uses the Python operating-cash-flow policy and SQLite persistence. All manually entered financial amounts are INR lakhs; uploaded financial documents use INR base rupees, as shown by the download template.

---

# WealthPilot

An SME loan underwriting and credit-research coursework project for Prof. Praveen Tammana. Includes a responsive credit workspace, persistent hosted API, and a portable Python research service with LangGraph and MCP.

## What runs where

| Component | Implementation | Persistence |
| --- | --- | --- |
| Hosted dashboard | React 19 / TypeScript / Vinext | Server-backed workspace |
| Hosted API | Cloudflare Worker route handlers | D1 applications/audit, R2 evidence |
| Hosted analysis | Deterministic document, financial, policy and review stages | Versioned results per case |
| Portable service | FastAPI, LangGraph specialist nodes | SQLite |
| Portable policy RAG | Hashed term vectors and cosine search | Versioned local policy corpus |
| Optional LLM research | OpenAI-compatible chat API with grounded citations | Explicit retrieval fallback |
| MCP server | Python MCP SDK, stdio tools/resources | Read-only research and calculation tools |

The **online hosted** dashboard does not invoke the local Python service. The **bundled local frontend** at `backend/static/` now does, through the same-origin `/api/*` adapter. It works without API keys using transparent calculations and keyword policy retrieval. The actual LangGraph/vector/MCP implementation is in `backend/`; follow its README to run it. No external LLM or credit-bureau provider is connected by default. Neither mode makes autonomous credit decisions.

## Use the dashboard

The initial empty workspace loads four **fictional coursework examples**. They demonstrate a passing screening, a policy breach, and missing information. No sample has a fabricated human approval.

1. Create an application. Enter loan size, operating history and annual financials in **INR lakhs**.
2. Attach a UTF-8 CSV/TXT source in the application's Documents tab (2,000,000-byte maximum; 20 documents maximum). All seven metrics must have matching source evidence. Download the template in the app.
3. Run assessment. Inspect ratios, policy references, agent traces and unresolved checks.
4. Correct inputs in Financials or remove conflicting evidence in Documents; both invalidate prior analysis.
5. Record a reviewer name and rationale in Decision. Approval is blocked by missing evidence or failed policy checks. Final Approved/Declined records are locked.
6. Export the application or workspace as JSON. Evidence sources can be previewed/downloaded individually. Audit records are retained server-side.

CSV columns use `metric,value`, with these keys:

```csv
metric,value
revenue,420
ebitda,86
debtService,48
currentAssets,186
currentLiabilities,104
totalDebt,180
equity,148
```

Debt and annual debt service must include the proposed facility. Use the same reporting period, unit and currency throughout. Hosted parsing is deliberately strict; arbitrary prose, OCR, unknown labels and unsupported formats are not silently guessed. Text PDFs are supported by the portable backend; scanned PDFs require an OCR integration. Unit conversion between the hosted and portable APIs is not automatic: hosted metrics are INR lakhs, portable metrics are base currency units and use operating cash flow rather than EBITDA.

## Hosted API

- `GET /api/workspace`: applications, policies, audit.
- `POST /api/demo`: idempotently load fictional examples.
- `POST /api/cases`: create an application from flat fields.
- `GET /api/cases/:id`: application and evidence metadata.
- `PATCH /api/cases/:id`: correct fields with current `version`.
- `POST /api/cases/:id/documents`: multipart `file`.
- `GET /api/cases/:id/documents/:docId`: full original source.
- `DELETE /api/cases/:id/documents/:docId?version=N`: remove evidence, audit and invalidate.
- `POST /api/cases/:id/analyze`: calculate current version.
- `POST /api/cases/:id/decision`: `{decision,reviewer,note,version}`.
- `POST /api/research`: `{question,caseId?}`; retrieved policy references.

Decisions: `Approved`, `Declined`, `More information`. Reviewer notes require 10–2000 characters. Errors return `{error}` with appropriate HTTP status. Mutations check same-origin requests, validate finite numeric ranges, use parameterized SQL, and protect concurrent changes with optimistic versions. Uploaded text is evidence, never executable instructions. The hosted score is rule-check completion, not a probability of default.

## Development

```bash
npm ci
npm run build
# Apply schema to local preview database after building:
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_fantastic_thunderbird.sql
npm run dev
```

The Sites-managed environment uses its supplied installation/build/preview helpers. `.openai/hosting.json` retains project identity and DB/BUCKET bindings; deployment provisions the server resources and applies migrations. Local preview and hosted databases are distinct.

## Validation

```bash
npx tsc --noEmit
node --experimental-strip-types lib/underwriting.test.mjs
cd backend
python -m unittest -v test_backend.py
```

Backend tests cover missing and zero-denominator inputs, invalid numbers, policy gates, conflicting and duplicate evidence, stale revisions, protected-field rejection, parser failures and LLM fallback. Install the portable requirements to run the actual LangGraph path. Provider calls require configured credentials and are not verified by no-key tests.

## Boundaries

This is a reviewable coursework implementation, not a production lending system. The policy corpus and borrowers are synthetic. Reviewer names are recorded assertions, not identity-verified roles. The hosted Site is private, but widening access would require a user/tenant authorization design before real borrower data is used. Audit data is persistent but not a tamper-proof ledger. Protected attributes are excluded, which is not a statistical fairness certification. Production readiness additionally requires institution-approved policy, independently validated credit models, verified source data, retention/encryption controls and security review.

Portable service setup, model configuration, samples, MCP invocation and its API contract: [backend/README.md](backend/README.md).
