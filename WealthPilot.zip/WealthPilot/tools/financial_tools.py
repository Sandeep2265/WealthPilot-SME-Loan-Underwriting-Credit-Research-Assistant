def calculate_profit_margin(profit: float, revenue: float) -> float:
    if revenue == 0:
        return 0.0
    return profit / revenue


def calculate_debt_to_equity(debt: float, equity: float) -> float:
    if equity == 0:
        return 0.0
    return debt / equity


def calculate_dscr(cash_flow: float, debt_obligation: float) -> float:
    if debt_obligation == 0:
        return 0.0
    return cash_flow / debt_obligation
