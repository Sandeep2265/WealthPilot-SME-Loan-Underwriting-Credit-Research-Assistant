# Persistent applicant memory will be implemented here.
