from fastapi import FastAPI

app = FastAPI(title="WealthPilot")

@app.get("/")
def root():
    return {"message": "WealthPilot is running"}
